// ============================================================
// WEBSITE CONFIGURATION — Edit this file to customize content
// ============================================================

export const config = {
  // --- SECURITY ---
  password: "bestfriend2024",

  // --- HINTS (shown in order, looping) ---
  hints: [
    "Hint 1: Think about our favorite memory together 💫",
    "Hint 2: It's a year... our year 🗓️",
    "Hint 3: It has numbers AND letters 🔢",
    "Hint 4: Related to friendship... hint hint 👫",
    "Hint 5: You've said this word a hundred times 😂",
    "Hint 6: Final hint: bestfriend + the year we met 🌟",
  ],

  // --- CONTACT INFO (shown on Secret Page) ---
  phoneNumber: "[PHONE_NUMBER]",
  instagramId: "[INSTAGRAM_ID]",
  snapchatId: "[SNAPCHAT_ID]",

  // --- SITE META ---
  siteTitle: "Developer's World",
  developerName: "Developer",
};
